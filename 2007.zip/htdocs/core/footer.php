<center>
<div id="Footer">
<hr/>
<p class="Legalese">
    <?=$sitename?>, "<?=$motto;?>", characters, logos, names, and all related indicia are trademarks of <a href="https://corp.roblox.com/">ROBLOX Corporation</a>, ©2009. Patents pending.<br>
<?=$sitename?> is not affliated with Lego, ROBLOX, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean.<br> ARrrr! 
    <br>
    Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="/info/TermsOfService.aspx">Terms and Conditions</a>.<br/>
    <a id="ctl00_rbxFooter_hlPrivacyPolicy" href="/info/Privacy.aspx">Privacy Policy</a>
    &nbsp;|&nbsp; <a href="mailto:<?=$site_email;?>">Contact Us</a> &nbsp;|&nbsp;
    <a href="/info/About.aspx">About Us</a> &nbsp;|&nbsp;
    <a id="ctl00_rbxFooter_hlAboutRoblox" href="https://discord.gg/<?=$discord;?>">Discord</a>  &nbsp;|&nbsp;
    <a id="ctl00_rbxFooter_hlAboutRoblox" href="/maintenance/status/">Status</a>
    <br>
	<br>

    Based off of December 2007
        
        </div>
      </div>
</form>
<center>
