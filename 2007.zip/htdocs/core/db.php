<?php
define('DB_SERVER', 'sql103.infinityfree.com');
define('DB_USERNAME', 'if0_40078860');
define('DB_PASSWORD', 'rurJBBtoFN');
define('DB_NAME', 'if0_40078860_roblox');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);