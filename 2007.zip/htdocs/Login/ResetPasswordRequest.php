<?php
include $_SERVER["DOCUMENT_ROOT"].'/core/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/core/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/core/config.php';
?>
<h1>Do you wish to change or reset your password? </h1>
</br>
<h1>Do you wish to change or reset your password? Dm carly, catzlol, or my username on discord to reset or change your password.</h1>
</br>

<?php
include $_SERVER["DOCUMENT_ROOT"].'/core/footer.php';
?>