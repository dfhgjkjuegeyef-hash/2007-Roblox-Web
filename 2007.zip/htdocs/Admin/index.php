<?php
include('include.php');
$renderServerCurl = curl_init();
curl_setopt($renderServerCurl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($renderServerCurl, CURLOPT_URL, $renderServerUrl);
curl_setopt($renderServerCurl, CURLOPT_SSL_VERIFYPEER, false);
$renderServerResult = curl_exec($renderServerCurl);
$RShttpCode = curl_getinfo($renderServerCurl, CURLINFO_HTTP_CODE);
curl_close($renderServerCurl);
if ($RShttpCode == 200 || $RShttpCode == 500) {
    $fuckYou = 'SOAP-ENV:Client';
    if (strpos($renderServerResult, $fuckYou) !== false) {
        $rson = true;
    } else {
        $rson = false;
    }
} else {
    $rson = false;
}
?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<div id="ItemContainer">
    <h2>Admin Panel</h2>
    <div id="Item">
<center>
    <h3 style="color: black;">What's up, <?php echo $_USER['username']; ?></h3>
    <br>
    <a style="color: blue;" href="ban.php">ban or unban someone</a><br>
    <a style="color: blue;" href="sitealerts.php">Change Site Alerts.</a><br>
    <a style="color: blue;" href="altidentification.php">Alt identification.</a><br>
    <a style="color: blue;" href="currencygift.php">Currency Gift.</a><br>
    <a style="color: blue;" href="givebuildersclub.php">Give Builders Club.</a><br>
    <a style="color: blue;" href="uploadasset.php">Upload an asset.</a><br>
    <a style="color: blue;" href="maintenance.php">Beta Maintenance.</a><br>
    <hr>
       <h3>RCCService (Avatar Rendering System)</h3>
    <p>O<?if($rson){?>n<?}else{?>ff<?}?>line</p>
<hr>
    <h3>Site Information</h3>
    <p><?=php_uname()?></p>
    <p style="color: grey;"><?=PHP_OS?></p>
    <p>Website Host name: <?=gethostname()?></p>
</center>