<?php include('include.php'); ?>
<?php if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usertoban = addslashes($_POST['usertoban']);
    $banreason = addslashes($_POST['banreason']);
    if($_POST['bantype'] == 'reminder') {$bantype = 'Reminder';} elseif($_POST['bantype'] == 'warning') {$bantype = 'Warning';} elseif($_POST['bantype'] == 'ban') {$bantype = 'Ban';} else {$bantype = 'None';}
    $banq = mysqli_query($link, "UPDATE `users` SET `bantype` = '".$bantype."', `banreason` = '".$banreason."', `bantime` = '".time()."' WHERE `users`.`username` = '".$usertoban."'; ") or die(mysqli_error($link));
} ?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<div id="ItemContainer">
    <h2>Ban Panel</h2>
    <div id="Item">
       
<center>
    <a href="index.php"><h1 style="color: black;">< Back</h1></a>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <input name="usertoban" type="text" tabindex="1" class="Text" placeholder="User to ban"><br> <br>
    <input id="bantype" type="radio" name="bantype" value="unban" checked="checked" tabindex="6"><label>Unban</label><br>
    <input id="bantype" type="radio" name="bantype" value="reminder" tabindex="6"><label>Reminder</label><br>
    <input id="bantype" type="radio" name="bantype" value="warning" tabindex="6"><label>Warning</label><br>
    <input id="bantype" type="radio" name="bantype" value="ban" tabindex="6"><label>Ban</label><br> <br>
    <input name="banreason" type="text" tabindex="1" class="Text" placeholder="Ban Reason"><br>
    <input type="submit" value="(Un)ban" tabindex="4" class="Button" name="submit">

    </form>
        <br>
           NOTICE: Do not be unprofessional in moderator notes.
</center>
<br>
<br>
<br>