<?php include($_SERVER["DOCUMENT_ROOT"]."/admin/include.php"); ?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<br>
<div id="ItemContainer">
    <div id="Item">
        
<center>
<center>
    <a href="/admin/index.php"><h1 style="color: black;">< Back</h1></a>
    <form method="POST" action="Admin/maintenanceenable.php/">
    <h1>Maintenance Mode</h1>
    <input id="enabled3" type="radio" name="enabled3"<?php if($_GLOBAL['maintenanceEnabled'] == 'yes') {echo ' checked="checked"';} ?> value="yes" tabindex="6"><label> Enable</label><br>
    <input id="enabled3" type="radio" name="enabled3"<?php if($_GLOBAL['maintenanceEnabled'] == 'no' ) {echo ' checked="checked"';} ?> value="no"  tabindex="6"><label> Disable</label><br>
        <br>
	its doest work yet.
    </form>
</center>