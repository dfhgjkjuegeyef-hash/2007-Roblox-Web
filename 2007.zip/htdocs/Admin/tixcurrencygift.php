<?php include('include.php'); ?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<br>
<div id="ItemContainer">
    <h2>Gift Tix</h2>
    <div id="Item">
        
<center>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $usertogift = mysqli_fetch_assoc(mysqli_query($link, "SELECT * FROM users WHERE username = '".addslashes(mysqli_real_escape_string($link, $_POST["username"]))."';"));
    $sql = "UPDATE users SET tix = tix + '".mysqli_real_escape_string($link, $_POST["count"])."' WHERE username = '".addslashes(mysqli_real_escape_string($link, $usertogift["username"]))."';";
    mysqli_query($link, $sql);
    echo "<h1>Successfully gifted ".htmlspecialchars($usertogift['username'])." ".mysqli_real_escape_string($link, $_POST['count'])." Tickets!</h1>";
}
?>
<center>
<a href="currencygift.php"><h1 style="color: black;">< Back</h1></a>
<form method="POST" action="">
    <input type="text" name="username" placeholder="Username to gift">
    <input type="text" name="count" placeholder="How many">
    <input type="submit" name="submit" value="Gift">
<br>
<br>
    <center>note : DO NOT GIVE YOURSELF A LOT OF TIX! YOU WILL KILL ECONOMY!</center>
</form>
</center>