<?php include('include.php'); ?>
<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usertogive = addslashes(mysqli_real_escape_string($link, $_POST['usertogive']));
    $expiredate = addslashes(mysqli_real_escape_string($link, $_POST['expiredate']));
    $givetype = addslashes(mysqli_real_escape_string($link, $_POST["bctype"]));
    mysqli_query($link, "UPDATE `users` SET `BC` = '".$givetype."', `BCExpire` = '".$expiredate."' WHERE `users`.`username` = '".$usertogive."'");
}
?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<div id="ItemContainer">
    <h2>Give Builder Club</h2>
    <div id="Item">
        
<center>
<center>
    <a href="index.php"><h1 style="color: black;">< Back</h1></a>
    <form method="POST" action="">
    <input name="usertogive" type="text" tabindex="1" class="Text" placeholder="User to gift"><br>
    <input name="bctype" type="text" tabindex="1" class="Text" placeholder="Type"><br>
    <input name="expiredate" type="text" tabindex="1" class="Text" placeholder="Expiration Date"><br>
    <input type="submit" value="Give" tabindex="4" class="Button" name="submit">
    </form>
</center>