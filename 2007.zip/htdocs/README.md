# NOUNBLOX: "An Good Nostalgia"
A roblox 2009 revival. 


# OVERVIEW AND SETUP

This site was originally hosted up on Ct8, however you can setup on any supported host. CT8 Seems to have weird issues copying, so copy each folder once at a time, to see what is the issue.

You must edit the DB.PHP file in the core folder to connect to a database. The SQL is in the root folder. Put this in phpmyadmin when you make a database with mysql.


# RENDER AND CLIENT 


You must patch your own client, and rendering service on RCC. This version of Nounblox used the 2016 version of rcc for rendering, and 2010L for client.

# AGREEMENTS

This source is open source, however you must change the name of the revival and make your edits open source as well. This is something to learn and jumpstart from, not to skid off without credit.

# CREDITS

NolanWhy and 608: Backend and Frontend edits.

Catzlol: Main owner of the original website.

All the previous moderators on NOUNBLOX.
